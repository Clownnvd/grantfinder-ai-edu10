﻿# PRD — GrantFinder AI

## Problem

Nhà nghiên cứu phải theo dõi nhiều website, đọc từng call-for-proposal và tự so điều kiện trước khi viết. Tìm bằng từ khóa tạo nhiều kết quả lệch trọng tâm; deadline, eligibility và biểu mẫu nằm rải trong HTML/PDF. Phòng KHCN khó theo dõi cơ hội, lý do matching và trạng thái duyệt trong một luồng thống nhất.

## Users

1. **Researcher:** nhập hướng nghiên cứu, nhận shortlist, chọn cơ hội, hoàn thiện draft.
2. **Research manager:** xác minh eligibility/deadline, review draft, approve hoặc yêu cầu sửa.

## User stories và DoD

| Story | DoD |
|---|---|
| Tìm cơ hội theo hướng nghiên cứu | Trả đúng 3 kết quả có score breakdown, URL và source span |
| Biết vì sao phù hợp | Hiện matched terms, eligibility verdict và thông tin còn thiếu |
| Không bỏ lỡ deadline | Dashboard chỉ đếm open call; sắp xếp deadline gần nhất |
| Dựng proposal | Chỉ chạy sau confirmation; mọi trường thiếu gắn `[NEEDS_INPUT]` |
| Phòng KHCN kiểm soát | Role manager mới ghi được approve/request changes |
| Audit agent | Mỗi run hiện tool, input summary, output summary, trạng thái và latency |
| Xử lý lỗi | pgvector/Gemini lỗi có fallback được ghi trong trace; app không crash |
| Giám sát hiệu lực | Phân loại call còn hiệu lực, sắp hết hạn, hết hiệu lực hoặc cần xác minh từ deadline nguồn |
| Tài khoản và phân quyền | Wireframe có đăng nhập/đăng ký; production kiểm tra session và role tại backend |

## Information architecture

1. **Khám phá cơ hội:** nhập hồ sơ, nhận top 3, xem lý do và citation.
2. **Dựng đề xuất:** xác nhận cơ hội, tạo draft, đánh dấu trường còn thiếu.
3. **Giám sát hiệu lực:** theo dõi deadline và mở nguồn kiểm tra.
4. **Hàng chờ phê duyệt:** manager approve hoặc yêu cầu sửa.
5. **Nguồn và đánh giá:** provenance, corpus size, retrieval mode và metrics.
6. **Đăng nhập/Đăng ký:** onboarding, email, mật khẩu và lựa chọn vai trò.

## Phân công wireframe

| Thành viên | Màn hình phụ trách | Definition of Done |
|---|---|---|
| Nguyễn Văn Duy | Màn chính/Khám phá cơ hội | Form hồ sơ, top 3, score, citation, trace và responsive |
| Dương Thị Ngân | Đăng nhập/Đăng ký | Hai mode, validation cơ bản, role selector, trạng thái thành công/lỗi |
| Vũ Huy Đô | Soạn hồ sơ + Giám sát hiệu lực | Draft/HITL/revision và 4 trạng thái deadline có URL kiểm chứng |

## Non-goals MVP

- Không tự nộp hồ sơ cho funder.
- Không khẳng định eligibility cuối cùng.
- Không lưu CV hoặc dữ liệu nghiên cứu chưa công bố thật.
- Không crawl Pivot-RP hay dữ liệu có license hạn chế.

## Success metrics

- Recall@3 ≥80% trên gold set.
- Citation coverage của hard facts =100%.
- Provider error =0 trong demo chính.
- Accuracy trích deadline/eligibility ≥80% khi có gold labels.
- Giảm thời gian shortlist/draft ≥50% chỉ được công bố sau user study thật.
